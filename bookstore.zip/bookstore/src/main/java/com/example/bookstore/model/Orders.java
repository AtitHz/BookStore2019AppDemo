package com.example.bookstore.model;

public class Orders {

	private long[] orders = {};

	public Orders() {

	}

	public long[] getOrders() {
		return orders;
	}

	public void setOrders(long[] orders) {
		this.orders = orders;
	}

}
