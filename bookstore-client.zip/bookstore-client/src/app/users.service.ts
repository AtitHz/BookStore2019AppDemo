import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from  '@angular/router';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};

import { Users } from "./users";
import { Orders } from "./orders";

@Injectable({
  providedIn: 'root'
})
export class UsersService {
	
	users: Users = new Users();
  
	private baseUrl = '/api/v1/users';
	private baseLoginUrl = '/api/v1/login';
	private baseOrderUrl = '/api/v1/users/orders';

	constructor(private http: HttpClient, private router: Router) { }

	getUserDetails(): Observable<Object> {
		httpOptions.headers = httpOptions.headers.set('Authorization', this.getAccessToken());
		return this.http.get(`${this.baseUrl}`, httpOptions);
	}
	
	deleteOrderHistory(): Observable<Object> {
		httpOptions.headers = httpOptions.headers.set('Authorization', this.getAccessToken());
		return this.http.delete(`${this.baseUrl}`, httpOptions);
	}
	
	userOrderBook(bookOrders: number[]): Observable<Object> {
		
		let orders: Orders = new Orders();
		orders.orders = bookOrders;
		
		console.log('userOrderBook -> ', orders);
		
		httpOptions.headers = httpOptions.headers.set('Authorization', this.getAccessToken());
		return this.http.post(`${this.baseOrderUrl}`, orders, httpOptions);
	}

 	createUsers(users: Object): Observable<Object> {
 		return this.http.post(`${this.baseUrl}`, users);
	}
 	
 	login(users: Object): Observable<Object> {
 		return this.http.post(`${this.baseLoginUrl}`, users);
	}
 	
	public loginToken(users: Users) {
		this.users = users;
		localStorage.setItem('ACCESS_TOKEN', this.users.id + '');
	}

	public isLoggedIn() {
		return localStorage.getItem('ACCESS_TOKEN') !== null;
	}
	
	public getAccessToken() {
		return localStorage.getItem('ACCESS_TOKEN');
	}

	public logout() {
		this.users = new Users();
		localStorage.removeItem('ACCESS_TOKEN');
		alert('Logout Success Go To Home');
		this.router.navigate(['home']);
	}

}
