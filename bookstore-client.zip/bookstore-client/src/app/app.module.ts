import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//import { FormsModule } from '@angular/forms';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateUsersComponent } from './create-users/create-users.component';
import { UsersDetailsComponent } from './users-details/users-details.component';
import { HttpClientModule } from '@angular/common/http';
import { BooksListComponent } from './books-list/books-list.component';
import { UsersLoginComponent } from './users-login/users-login.component';
import { UsersOrdersComponent } from './users-orders/users-orders.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateUsersComponent,
    UsersDetailsComponent,
    BooksListComponent,
    UsersLoginComponent,
    UsersOrdersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
