import { Component, OnInit } from '@angular/core';
import { Router } from  '@angular/router';

import { HttpHeaders } from '@angular/common/http';

import { Users } from "./../users";
import { UsersInformation } from "./../usersInformation";
import { UsersService } from './../users.service';

//const httpOptions = {
//  headers: new HttpHeaders({
//    'Content-Type':  'application/json',
//    'Authorization': 'my-auth-token'
//  })
//};

@Component({
  selector: 'app-users-details',
  templateUrl: './users-details.component.html',
  styleUrls: ['./users-details.component.css']
})
export class UsersDetailsComponent implements OnInit {
	
	users: UsersInformation = new UsersInformation();

	constructor(private usersService: UsersService, private router: Router) { }

	ngOnInit() {
		if (!window.localStorage.getItem('ACCESS_TOKEN')) {
			this.router.navigate(['login']);
			return;
		}
		
		this.reloadData();
	}
	
	reloadData() {
		this.usersService.getUserDetails()
			.subscribe((data: UsersInformation) => {
					console.log('reloadData -> ', data);
					this.users = data;
					console.log('reloadData -> this.users ', this.users);
				}
				, error => {
					console.log(error);
					alert(error.message);
				});
	}
	
	deleteOrderHistory() {
		this.usersService.deleteOrderHistory()
			.subscribe(data => {
					console.log('deleteOrderHistory -> ', data);
					alert('Delete Order Success Go To Home');
					this.router.navigate(['home']);
				}
				, error => {
					console.log(error);
					alert(error.message);
				});
	}

}
