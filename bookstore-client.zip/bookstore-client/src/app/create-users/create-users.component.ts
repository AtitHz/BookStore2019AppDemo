import { Observable } from "rxjs";
import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from  '@angular/router';
import { UsersService } from "./../users.service";
import { Users } from "./../users";
import { UsersInformation } from "./../usersInformation";

@Component({
	selector: 'app-create-users',
	templateUrl: './create-users.component.html',
	styleUrls: ['./create-users.component.css']
})
export class CreateUsersComponent implements OnInit {

	users: Users = new Users();
	usersInformation: UsersInformation = new UsersInformation();
	createForm: FormGroup;
	isSubmitted = false;

	constructor(private usersService: UsersService, private router: Router, private formBuilder: FormBuilder ) {}

	ngOnInit() {
		this.createForm  =  this.formBuilder.group({
	        firstName: ['', Validators.required],
	        lastName: ['', Validators.required],
	        date_of_birth: ['', Validators.required],
	        password: ['', Validators.required],
	        confirmPassword: ['', Validators.required]
	    });
	}
	
	get formControls() { return this.createForm.controls; }

	newUsers(): void {
		this.isSubmitted = false;
		this.users = new Users();
	}

	save() {
		this.usersInformation = this.createForm.value;
		
		this.users.username = this.usersInformation.firstName + "." + this.usersInformation.lastName;
		this.users.password = this.usersInformation.password;
		this.users.date_of_birth = this.usersInformation.date_of_birth;
		
		this.usersService.createUsers(this.users)
			.subscribe((data: Users) => {
					console.log(data);
					this.usersService.loginToken(data);
					this.router.navigate(['home']);
				}
				, error => {
					console.log(error);
					alert(error.message);
				});
		this.users = new Users();
	}

	onSubmit() {
		
		console.log(this.createForm.value);
		this.isSubmitted = true;
		if (this.createForm.invalid) {
		  return;
		}
		
		this.save();
		
//		this.router.navigateByUrl('/home');
	}

}
