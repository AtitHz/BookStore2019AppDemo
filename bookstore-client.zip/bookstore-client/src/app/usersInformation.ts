export class UsersInformation {
    id: number;
	name: string;
	surname: string;
    date_of_birth: string;
	book: number[] = [];

	firstName: string;
	lastName: string;
	password: string;
	confirmPassword: string;
}