import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from  '@angular/forms';
import { Router } from  '@angular/router';
import { Users } from  '../users';
import { UsersService } from  '../users.service';

@Component({
  selector: 'app-users-login',
  templateUrl: './users-login.component.html',
  styleUrls: ['./users-login.component.css']
})
export class UsersLoginComponent implements OnInit {
	
	loginForm: FormGroup;
	isSubmitted  =  false;

	constructor(private usersService: UsersService, private router: Router, private formBuilder: FormBuilder ) { }

	ngOnInit() {
		this.loginForm  =  this.formBuilder.group({
	        username: ['', Validators.required],
	        password: ['', Validators.required]
	    });
	}
	
	get formControls() { return this.loginForm.controls; }
	
	login() {
		console.log(this.loginForm.value);
		this.isSubmitted = true;
		if (this.loginForm.invalid) {
		  return;
		}
//		this.usersService.login(this.loginForm.value);
		
		this.usersService.login(this.loginForm.value)
			.subscribe((data: Users) => {
				
				if (data == null) {
					console.log('Error Unknow');
					alert('Error Unknow');
					return;
				}
				
					console.log(data);
					this.usersService.loginToken(data);
					this.router.navigate(['home']);
				}
				, error => {
					console.log(error);
					alert(error.message);
				});
		
//		this.router.navigateByUrl('/home');
	}

}
