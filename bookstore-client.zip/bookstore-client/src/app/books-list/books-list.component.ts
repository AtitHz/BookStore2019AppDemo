import { Observable } from "rxjs";
import { map } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, ValidatorFn, Validators } from '@angular/forms';
import { Router } from  '@angular/router';

import { BooksService } from "./../books.service";
import { Books } from "./../books";
import { UsersService } from  './../users.service';

//import { Users } from "./../users";
//import { UsersInformation } from "./../usersInformation";

@Component({
	selector: 'app-books-list',
	templateUrl: './books-list.component.html',
	styleUrls: ['./books-list.component.css']
})
export class BooksListComponent implements OnInit {

//	usersInformation: UsersInformation = new UsersInformation();
//	submitted = false;
	bookOrderId: number[] = [];
	booksList: Observable<Books[]>;
	
	constructor(private booksService: BooksService, private usersService: UsersService, private formBuilder: FormBuilder, private router: Router) {}
	
	ngOnInit() {
		this.reloadData();
	}
	
	reloadData() {
		this.booksList = this.booksService.getBooksList();
	}
	
//	newUsers(): void {
//		this.submitted = false;
//		this.users = new Users();
//	}
//	
//	save() {
//		this.users.username = this.usersInformation.firstName + "." + this.usersInformation.lastName;
//		this.users.password = this.usersInformation.password;
//		this.users.date_of_birth = this.usersInformation.date_of_birth;
//		
//		this.usersService.createUsers(this.users)
//			.subscribe(data => console.log(data), error => console.log(error));
//		this.users = new Users();
//	}
//	
//	onSubmit() {
//		this.submitted = true;
//		this.save();
//	}
	index: number;
	changeStatus(bookId: number, event: Event) {
		console.log('bookId ->', bookId);
//		console.log('event ->', event);
		console.log('event.srcElement.checked ->', (<HTMLInputElement>event.srcElement).checked);
		
//		index: number = -1;
//		let scores: number[] = [10, 20, 30, 40];
//		scores.push( 50 );  //[10, 20, 30, 40, 50]
//		console.log('scores -> ' + scores)
		
		if ((<HTMLInputElement>event.srcElement).checked === true) {
			this.bookOrderId.push(bookId);
			
		} else {
			this.index = this.bookOrderId.indexOf(bookId);
			if (this.index > -1) {
				this.bookOrderId.splice(this.index, 1);
			}
		}
		
		console.log('bookOrderId ->', this.bookOrderId);
	}
	
	userOrder() {
		this.usersService.userOrderBook(this.bookOrderId)
			.subscribe(data => {
				
					if (data == null) {
						console.log('Error Unknow');
						alert('Error Unknow');
						return;
					}
				
					console.log(data);
//					alert('Order Book Price [' + data.price + ']');
					alert('Order Book Price Success');
					this.router.navigate(['users']);
				}
				, error => {
					console.log(error);
					alert(error.message);
				});
	
	}
	
}
