export class Users {
    id: number;
    username: string;
	password: string;
    date_of_birth: string;
}