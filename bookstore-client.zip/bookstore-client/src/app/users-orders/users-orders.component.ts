import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users-orders',
  templateUrl: './users-orders.component.html',
  styleUrls: ['./users-orders.component.css']
})
export class UsersOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
