import { Component, OnInit } from '@angular/core';
import { UsersService } from  './users.service';
import { Users } from  './users';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
	title = 'Book Store Application Demo';
	
	constructor(private usersService: UsersService) { }
	
	ngOnInit() {
	}
  
}
