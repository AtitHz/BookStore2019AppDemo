import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BooksListComponent } from './books-list/books-list.component';
import { UsersDetailsComponent } from './users-details/users-details.component';
import { CreateUsersComponent } from './create-users/create-users.component';
import { UsersLoginComponent } from './users-login/users-login.component';

import { AuthGuard } from './auth.guard';

//import { NgModule } from '@angular/core';
//import { Routes, RouterModule } from '@angular/router';
//import { EmployeeListComponent } from './employee-list/employee-list.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: BooksListComponent },
//  { path: 'books', component: BooksListComponent },
  { path: 'users', component: UsersDetailsComponent, canActivate: [AuthGuard] },
//  { path: 'users', component: UsersDetailsComponent },
  { path: 'register', component: CreateUsersComponent },
  { path: 'login', component: UsersLoginComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
