export class Orders {
	orders: number[] = [];
}